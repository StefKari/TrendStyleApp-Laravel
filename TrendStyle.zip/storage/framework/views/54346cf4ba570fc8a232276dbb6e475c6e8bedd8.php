

<?php $__env->startSection('content'); ?>

<?php if(!Auth::guest()): ?>
   <?php if(auth()->user()->is_admin == 1): ?>
    <div class="container mt-4">
      <a href="/gallery/kreiraj" class="btn btn-warning">Dodaj Fotografiju u Galeriju</a>
    </div>
  <?php endif; ?>
<?php endif; ?>
<div class="container py-4">
   <div class="row mt-4">
    <?php if(count($images) > 0): ?>
      <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-xl-6 col-lg-6 col-md-6 col-xs-12">
          <div class="card mb-3">
              <a href="<?php echo e(asset($image->gallery)); ?>">
                <img src="<?php echo e(asset($image->gallery)); ?>" class="card-img-top rounded" alt="Images" height="500px">
              </a>
              <div class="text-center">
                <?php if(!Auth::guest()): ?>
                   <?php if(auth()->user()->is_admin == 1): ?>
                    <?php echo Form::open(['action' => ['GalleryController@destroy', $image->id],'method' => 'POST', 'class' => 'pull-right']); ?>

                      <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                      <?php echo e(Form::submit('Izbriši',['class' => 'btn btn-danger izbriši'])); ?>

                    <?php echo Form::close(); ?>

                   <?php endif; ?>
                <?php endif; ?>
              </div>
           </div>
         </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Trenutno nema Galerije!</p>
      <?php endif; ?>
    <?php endif; ?>
   </div>
   <div class="row justify-content-center mt-2 mb-2">
     <?php echo e($images->links()); ?>

   </div>
</div>
<script type="text/javascript">

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/gallery/galerija.blade.php ENDPATH**/ ?>
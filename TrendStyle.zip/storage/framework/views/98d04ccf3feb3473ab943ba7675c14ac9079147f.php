<header id="header">
  <nav class="navbar navbar-expand-md navbar-light shadow-sm">
      <div class="container">
          <a id="logo-ime" class="navbar-brand" href="<?php echo e(url('/')); ?>">
              Trend Style
          </a>
          <button id="hamburger" class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
              <i id="hamburger" class="fas fa-bars"></i>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <!-- Desna strana Navbara -->
              <ul id="navigacija" class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/">POČETNA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/o-nama">O NAMA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/usluge">USLUGE</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/cene">CENE</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/galerija">GALERIJA</a>
                </li>
                <li class="nav-item mr-1">
                    <a class="nav-link" href="/kontakt">KONTAKT</a>
                </li>
                  <!-- Authentication Linkovi -->
                  <?php if(auth()->guard()->guest()): ?>

                  <?php else: ?>
                      <li class="nav-item dropdown">
                          <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                              <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                          </a>

                          <div id="admin-lista" class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <?php if(auth()->user()->is_admin == 1): ?>
                              <a class="dropdown-item" href="<?php echo e(route('admin')); ?>">
                                Admin Panel
                              </a>
                            <?php endif; ?>
                              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                 onclick="event.preventDefault();
                                               document.getElementById('logout-form').submit();">
                                  <?php echo e(__('Logout')); ?>

                              </a>

                              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                  <?php echo csrf_field(); ?>
                              </form>
                          </div>
                      </li>
                  <?php endif; ?>
              </ul>
          </div>
      </div>
  </nav>
</header>
<?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/inc/navbar.blade.php ENDPATH**/ ?>
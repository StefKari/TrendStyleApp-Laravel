<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><h3>Admin Panel</h3></div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <h3 class="py-4">Usluge</h3>
                    <div class="row">
                      <div class="col-md-4">
                        <p>Kreiraj Uslugu..</p>
                        <a href="/posts/create" class="btn btn-primary my-3">Kreiraj</a>
                      </div>
                      <div class="col-md-4">
                        <p>Edituj Uslugu...</p>
                        <a href="/usluge" class="btn btn-primary my-3">Edituj</a>
                      </div>
                      <div class="col-md-4">
                        <p>Izbrisi uslugu...</p>
                        <a href="/usluge" class="btn btn-primary my-3">Izbrisi</a>
                      </div>
                    </div>
                    <h3 class="py-4">Galerija</h3>
                </div>
            </div>
        </div>
    </div>

</div>
<div class="prazan">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views//home.blade.php ENDPATH**/ ?>
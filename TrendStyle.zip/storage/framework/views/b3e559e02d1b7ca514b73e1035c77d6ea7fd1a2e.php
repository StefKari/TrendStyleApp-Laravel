

<?php $__env->startSection('content'); ?>

<div class="container py-4">
  <div class="row">
    <div class="col-md-8 mt-4">
      <table class="table table-kat">
        <thead>
          <tr>
            <th>Ime kategorije</th>
            <th>Opcija / Izbriši</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vrednost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th><?php echo e($vrednost->name); ?></th>
            <th>
              <?php if(!Auth::guest()): ?>
               <?php if(auth()->user()->is_admin == 1): ?>
                <?php echo Form::open(['action' => ['CategoryController@destroy', $vrednost->id],'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Izbriši',['class' => 'btn btn-danger izbriši'])); ?>

                <?php echo Form::close(); ?>

                <?php endif; ?>
              <?php endif; ?>
            </th>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <div class="col-md-4 mt-4">
      <?php if(!Auth::guest()): ?>
        <?php if(auth()->user()->is_admin == 1): ?>
          <h3 class="mb-4">Kreiraj kategoriju:</h3>
            <?php echo Form::open(['action' => 'CategoryController@store', 'method' => 'POST']); ?>

              <div class="form-group">
                <?php echo e(Form::label('ime','Ime Kategorije:')); ?>

                <?php echo e(Form::text('ime','',['class' => 'form-control'])); ?>

              </div>
            <?php echo e(Form::submit('Kreiraj',['class' => 'btn admin-btn'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/category/kategorije.blade.php ENDPATH**/ ?>
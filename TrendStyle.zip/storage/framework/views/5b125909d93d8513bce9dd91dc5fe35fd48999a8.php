

<?php $__env->startSection('content'); ?>

<div class="container py-4">

  <h2 class="mb-4">Kreiraj Galeriju:</h2>

    <?php echo Form::open(['action' => 'GalleryController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

      <div class="form-group">
        <?php echo e(Form::label('gallery','Dodaj Fotografiju u Galeriju:')); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::file('image[]')); ?>

      </div>
    <?php echo e(Form::submit('Kreiraj',['class' => 'btn admin-btn'])); ?>

    <?php echo Form::close(); ?>


</div>
<div class="prazan">
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/gallery/kreiraj.blade.php ENDPATH**/ ?>
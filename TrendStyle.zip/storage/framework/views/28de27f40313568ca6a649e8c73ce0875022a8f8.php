

<?php $__env->startSection('content'); ?>

<div class="container py-4">

   <div class="row">
      <div class="col-md-12">
        <a href="/usluge" class="btn btn-light my-3">Vrati se nazad</a>
      </div>
    </div>
    <div class="row">
       <div class="col-md-12">
         <h1><?php echo e($post->title); ?></h1>
         <small>Written on <?php echo e($post->updated_at); ?></small>
      </div>
    </div>
    <hr>
    <div class="row">
       <div class="col-md-12">
        <p><?php echo e($post->body); ?></p>
       </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <img style="width:50%;" src="../storage/image/<?php echo e($post->image); ?>" alt="Images">
      </div>
    </div>
   <?php if(!Auth::guest()): ?>
      <?php if(auth()->user()->name=="Jeka"): ?>
        <div class="row my-4">
          <div class="col-md-12">
            <a href="/usluga/<?php echo e($post->id); ?>/edit" class="btn btn-success">Edit</a>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <?php echo Form::open(['action' => ['PostsController@destroy', $post->id],'method' => 'POST', 'class' => 'pull-right']); ?>

              <?php echo e(Form::hidden('_method', 'DELETE')); ?>

              <?php echo e(Form::submit('Delete',['class' => 'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

          </div>
        </div>
      <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/posts/show.blade.php ENDPATH**/ ?>
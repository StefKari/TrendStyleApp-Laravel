<?php $__env->startComponent('mail::message'); ?>

<h2>Rezervacija</h2>

<strong>Ime i Prezime:</strong> <?php echo e($contact['ime_prezime']); ?><br>
<strong>Telefon:</strong> <?php echo e($contact['telefon']); ?><br>
<strong>Email:</strong> <?php echo e($contact['email']); ?><br>
<strong>Usluga:</strong> <?php echo e($contact['usluga']); ?><br>
<strong>Dan:</strong> <?php echo e($contact['dan']); ?>

<strong>Mesec:</strong> <?php echo e($contact['mesec']); ?>

<strong>Vreme:</strong> <?php echo e($contact['vreme']); ?><br>
<strong>Poruka:</strong><br>
<?php echo e($contact['poruka']); ?>


<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/emails/contact/contact-form.blade.php ENDPATH**/ ?>
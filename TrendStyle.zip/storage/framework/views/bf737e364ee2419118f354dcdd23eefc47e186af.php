

<?php $__env->startSection('content'); ?>

<div class="container py-4">

  <h2 class="mb-4">Edituj uslugu:</h2>

  <?php echo Form::open(['action' => ['PostsController@update', $post->id],'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <?php echo e(Form::label('category_id','Kategorija:')); ?>

    <div class="form-group">
      <select class="form-control" name="category_id">
          <?php $selectedVrednost = $post->category_id?>
          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vrednost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($vrednost->id); ?>" <?php echo e($selectedVrednost == $vrednost['id'] ? 'selected="selected"' : ''); ?>><?php echo e($vrednost->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group">
      <?php echo e(Form::label('title','Naslov:')); ?>

      <?php echo e(Form::text('title', $post->title, ['class' => 'form-control','placeholder' => 'Naslov'])); ?>

    </div>
    <div class="form-group">
      <?php echo e(Form::label('body','Tekst:')); ?>

      <?php echo e(Form::textarea('body', $post->body, ['class' => 'form-control','placeholder' => 'Tekst'])); ?>

    </div>
    <div class="form-group">
      <?php echo e(Form::file('image')); ?>

    </div>
  <?php echo e(Form::hidden('_method','PUT')); ?>

  <?php echo e(Form::submit('Edituj',['class' => 'btn btn-warning edituj'])); ?>

  <?php echo Form::close(); ?>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/posts/edit.blade.php ENDPATH**/ ?>
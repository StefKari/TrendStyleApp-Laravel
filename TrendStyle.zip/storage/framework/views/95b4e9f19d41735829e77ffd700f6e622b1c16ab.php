

<?php $__env->startSection('content'); ?>

<div class="container py-4">

  <h2 class="mb-4">Kreiraj uslugu:</h2>
    <?php echo Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

      <?php echo e(Form::label('category_id','Kategorija:')); ?>

      <div class="form-group">
        <select class="form-control" name="category_id">
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vrednost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($vrednost->id); ?>"><?php echo e($vrednost->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <?php echo e(Form::label('title','Naslov:')); ?>

        <?php echo e(Form::text('title','',['class' => 'form-control'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::label('body','Tekst:')); ?>

        <?php echo e(Form::textarea('body','',['class' => 'form-control'])); ?>

      </div>
      <div class="form-group">
        <?php echo e(Form::file('image')); ?>

      </div>
    <?php echo e(Form::submit('Kreiraj',['class' => 'btn admin-btn'])); ?>

    <?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/posts/kreiraj.blade.php ENDPATH**/ ?>
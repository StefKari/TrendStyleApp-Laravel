<div class="container pb-0 mb-0">
<!-- Authentication Links -->
<ul class="navbar-nav ml-auto">
<?php if(auth()->guard()->guest()): ?>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('login')); ?>"><i id="admin" class="fa fa-user" aria-hidden="true"></i></a>
    </li>

<?php else: ?>
    <li class="nav-item dropdown">
        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
        </a>

        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
          <?php if(auth()->user()->name=="Jeka"): ?>
            <a class="dropdown-item" href="<?php echo e(route('home')); ?>">
              Admin Panel
            </a>
          <?php endif; ?>
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                             document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </li>
<?php endif; ?>
</ul>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/inc/first-nav.blade.php ENDPATH**/ ?>
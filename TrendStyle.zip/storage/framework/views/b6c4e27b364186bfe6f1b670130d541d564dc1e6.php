

  <div id="Glavni-slider" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#Glavni-slider" data-slide-to="0" class="active"></li>
    <li data-target="#Glavni-slider" data-slide-to="1"></li>
    <li data-target="#Glavni-slider" data-slide-to="2"></li>
  </ul>

  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="/img/naslovna1.jpg" alt="Los Angeles" width="100%" height="600">
    </div>
    <div class="carousel-item">
      <img src="/img/naslovna2.jpg" alt="Chicago" width="100%" height="600">
    </div>
    <div class="carousel-item">
      <img src="/img/naslovna3.jpg" alt="Chicago" width="100%" height="600">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#Glavni-slider" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#Glavni-slider" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
  </div>
<?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/inc/slider.blade.php ENDPATH**/ ?>
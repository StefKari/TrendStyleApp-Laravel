

<?php $__env->startSection('content'); ?>

<div id="usluga" class="container py-4 responziv-center">

    <div class="row mt-2">
       <div class="col-md-12">
         <h2 class="mb-4"><?php echo e($post->title); ?></h2>
         <small>Objavljeno:<?php echo e($post->updated_at); ?></small>
         <p id="kategorija" class="mt-2">Kategorija: <?php echo e($post->category->name); ?></p>
      </div>
    </div>
    <hr>
    <div class="row">
       <div class="col-md-12">
        <p><?php echo e($post->body); ?></p>
       </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <img class="rounded" style="width:60%;" src="../storage/image/<?php echo e($post->image); ?>" alt="Images">
      </div>
    </div>
    <?php if(!Auth::guest()): ?>
      <?php if(auth()->user()->is_admin == 1): ?>
        <div class="row my-4">
          <div class="col-md-12">
            <a href="/usluga/<?php echo e($post->id); ?>/edit" class="btn btn-warning edituj"><i class="fas fa-edit"></i> Edituj</a>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <?php echo Form::open(['action' => ['PostsController@destroy', $post->id],'method' => 'POST', 'class' => 'pull-right']); ?>

              <?php echo e(Form::hidden('_method', 'DELETE')); ?>

              <?php echo e(Form::button('<i class="fas fa-trash-alt"></i> Izbriši',['type' => 'submit', 'class' => 'btn btn-danger izbriši'])); ?>

            <?php echo Form::close(); ?>

          </div>
        </div>
      <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

</div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TrendStyle\resources\views/posts/usluga.blade.php ENDPATH**/ ?>
@extends('layouts.app')

@section('content')

<div class="container py-4">
  <div class="row responziv-center">
    <div class="col-md-4 mt-4 mb-4">
      <img class="rounded" style="width:80%;" src="/img/jeka.jpg" alt="Images">
    </div>
    <div class="col-md-8 mt-4 mb-4 o-nama">
      <p>Salon <span>Trend Style</span> je zvanično počeo sa radom 2006 godine.Nalazimo se preko puta crkve Svete Trojice i Abraševića a pored Doma Vojske Srbije.Na ovoj lokaciji smo od samog otvaranja tačnije više od 14 godina.Profesionalsnost i srdačna atmosfera je nešto što nas odvaja od konkurencije.Za svo ovo vreme smo stekli stalne mušterije koje dolaze kod nas više od 12 godina.Ali posebno mesto naravno kod nas imaju nove mušterije.Usluge uglavnom vršimo rezervacijom koje možete ostvariti na sajtu preko stranice kontakt ili direktnim pozivom na broj <span> +381694546605</span> .Naravno uvek smo otvoreni za bilo kakav dogovor i ustupak jer komunikacija sa mušterijom nam je prevashodna stvar.</p>
      <p></p>
    </div>
  </div>
</div>

@endsection
